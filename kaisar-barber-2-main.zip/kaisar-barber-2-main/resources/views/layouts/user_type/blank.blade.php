@extends('layouts.app')

@section('auth')
    @yield('content')
@endsection

@section('guest')
    @yield('content')
@endsection